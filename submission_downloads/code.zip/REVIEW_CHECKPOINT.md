# Selected evidence-based prediction submission

This archive contains the selected runnable implementation, mandatory reports and supporting documentation. No output.csv is included inside the code archive. A separately supplied output.csv may be an explicitly assumption-dependent prediction candidate; it is not a completed strict audit. Read code/evaluation/approach_comparison.md and its assumptions ledger. The original518-row requirement and excluded-row format remain pending organizer clarification.

Supply the original participant dataset alongside code/. Start with README.md and code/FRESH_ENVIRONMENT.md. Read evaluation/archive_verification.md for actually tested versus documented behavior. Partial predictions, detailed diagnostics and the transcript are preserved separately as review artifacts. No dataset, credentials, model caches, virtual environment or nested archive is included. Paid API budget:$0.
